import json

s = {
"photo": {
"dates": {
"posted": "1458226950"
},
"description": {
"_content": "Geroldsee in Bavaria, taken with my Hasselblad and Velvia Film."
},
"views": "996",
"tags": {
"tag": [
{
"machine_tag": False,
"authorname": "Kaspartheater",
"id": "76840640-25559101960-03",
"_content": "bavaria"
},
{
"machine_tag": False,
"authorname": "Kaspartheater",
"id": "76840640-25559101960-1695",
"_content": "landscape"
},
{
"machine_tag": False,
"authorname": "Kaspartheater",
"id": "76840640-25559101960-201",
"_content": "winter"
}
]
},
"visibility": {
"isfriend": 0,
"ispublic": 1
},
"title": {
"_content": "Mirror Mountains"
}
},
"stat": "ok"
}

def count_letters(s='test string', chs='aeiou'):
	count = 0
	for c in s:
		if c in chs:
			count +=1
	return count

def extract_tags(s):

	tag_ds = s['photo']['tags']['tag']
	return [d['_content'] for d in tag_ds]
def vowel_tag(s):
	tags = extract_tags(s)
	sorted_tags = sorted(tags, key = lambda x: count_letters(x), reverse = True)
	return sorted_tags[0]
def my_vowel(s):
	tag_ls=extract_tags(s)
	count_dic={}
	for i in tag_ls:
		count_dic[i]=count_letters(i)
	sort_dic=sorted(count_dic,key=lambda x: count_dic[x], reverse=True)
	return sort_dic[0]

print vowel_tag(s)
print my_vowel(s)