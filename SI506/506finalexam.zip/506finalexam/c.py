students = [("Jones, Jamal J", 98, "A+"),
			("Ensted, Eloise E", 87, "B+"),
			("Morton, Madeline", 99, "A+")]

outfile = open("grades.csv","w")
# output the header row
outfile.write('"score", "name", "grade"\n')
# output each of the rows:
for student in students:
	outfile.write('"{}", "{}", "{}"\n'.format(*student))
outfile.close()
