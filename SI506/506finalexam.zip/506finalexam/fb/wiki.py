import wikipedia
import json



class Wiki():
	def __init__(self,query):
		self.query=query
	def summary(self):
		return wikipedia.summary(self.query,sentences=1)
	def __str__(self):
		return 'The page is {}'.format(self.query)

c=wikipedia.summary('China')

f = open("china.txt", 'w')
f.write(json.dumps(c))
f.close()
