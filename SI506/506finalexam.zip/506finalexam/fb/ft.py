# import statements
import unittest
import json
import requests
import pickle
import webbrowser
       
base_url = "https://api.flickr.com/services/rest/"
params_d = {}
params_d['method'] = 'flickr.photos.search'
params_d['api_key'] = "e000708b861dce5e414251b565994ada"
params_d['format'] = 'json'
params_d['tags'] = ['China']
params_d['tag_mode'] = 'all'
params_d['per_page'] = 1
r = requests.get(base_url, params=params_d)
print json.loads(r.text[14:-1])      





#params_d['method'] = 'flickr.urls.getUserPhotos'
#params_d['api_key'] = flickr_key
#params_d['user_id'] = idtuple[0]

#pho = requests.get(base_url, params=params_d)
#print json.loads(pho.text[14:-1])


