import json
import requests

def pretty(obj):
    return json.dumps(obj, sort_keys=True, indent=2)

# get access token from 
# https://developers.facebook.com/tools/explorer"
access_token = None

if access_token == None:
    access_token = raw_input("\nCopy and paste token from https://developers.facebook.com/tools/explorer\n>  ") 
# Make sure to use version 2.3 (dropdown on the left of the token at the top of the screen) and check the box for user_groups permission

fb_class_id = '323187111349524'

baseurl = "https://graph.facebook.com/v2.3/{}/feed"  

# Building the Facebook parameters dictionary
url_params = {}
url_params["access_token"] = access_token
url_params["fields"] = "comments{like_count,from,message,created_time},likes,message,created_time,from"

# Try and get a response, see what it looks like
r = requests.get(baseurl.format(fb_class_id),params=url_params)
print r.status_code
print r.text
feed = json.loads(r.text)

# Try out these, try out some more..!
print type(feed)
print feed.keys()
print type(feed['data'])
print len(feed['data'])
print pretty(feed['data'][2])
print feed['data'][2]["message"]