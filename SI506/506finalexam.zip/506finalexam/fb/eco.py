import json
import requests

access_token = 'EAACEdEose0cBAGJSM4jW9zDZCSwGederw74I3KJejMxrnoer4f3mXleE7w6BxvWpihmc5aHZCXV94ZA89RnCOg9iBGYLwN8hnDw7XqNbu7lRC6EYqKSrNDDHKONgptIZAGmaIG8RNiVQ3romEi6rdqo6bnbS44y4eaabohMP5gZDZD'

if access_token == None:
    access_token = raw_input("\nCopy and paste token from https://developers.facebook.com/tools/explorer\n>  ") 
# Make sure to use version 2.3 (dropdown on the left of the token at the top of the screen) and check the box for user_groups permission

fb_class_id = '6013004059'

baseurl = "https://graph.facebook.com/v2.3/{}/feed"  

# Building the Facebook parameters dictionary
url_params = {}
url_params["access_token"] = access_token
url_params["fields"] = "message,created_time"
url_params["limit"]=25

# Try and get a response, see what it looks like
r = requests.get(baseurl.format(fb_class_id),params=url_params)
feed = json.loads(r.text)

try:
    f = open("eco.txt", 'r')
    cnn_dic= json.loads(f.read())
    f.close()
except:
    f = open("eco.txt", 'w')
    f.write(json.dumps(feed))
    f.close()
    cnn_dic=feed

word_countdic={}
for each_massage in cnn_dic['data']:
	if 'message' in each_massage:
		message_list=each_massage['message'].split()
		#print message_list
		for i in message_list:
			if i not in word_countdic:
				word_countdic[i]=0
			word_countdic[i]+=1
word_20=sorted(word_countdic,key=lambda x: word_countdic[x],reverse=True)[:100]
for i in word_20:
	print i,word_countdic[i]

outfile = open("eco_word.csv","w")
outfile.write("word, counts\n")
for i in word_20:
    outfile.write("{},{}\n".format(i.encode('utf-8'),word_countdic[i]))
outfile.close()