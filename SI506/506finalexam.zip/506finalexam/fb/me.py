import requests
import json

access_token = 'EAACEdEose0cBAPYcEiah0HhyDaZBe1njTakKBpSV00zMrGp5UMtVrc9R2TcjfXxSRgP5XG2ZCzwZC0NZB0SVzZCMUYG9bZBsOlhEdqPRw78gEYaCLmWS1FZCqcPrjHWWYoQrSJ8erRUYpRINpkjps2iGP2SdMcVQ5QRX7GYOmhp3QZDZD'

group_id = '323187111349524'
if access_token is None:
    access_token = raw_input("\nCopy and paste token from https://developers.facebook.com/tools/explorer\n>  ")
if group_id is None:
    group_id = raw_input("\nCopy and paste your userid or FB group id: ")
url_params = {
    "access_token": access_token,
    "fields": "message,comments,likes"
}
baseurl = "https://graph.facebook.com/{}/feed".format(group_id)
r = requests.get(baseurl ,params=url_params)
# print r.url
feed = json.loads(r.text)
#print json.dumps(feed, indent=2)

#Print out the text of all the messages returned in the feed
for each in feed['data']:
    if 'message' in each:
        print each['message'].encode('utf-8')