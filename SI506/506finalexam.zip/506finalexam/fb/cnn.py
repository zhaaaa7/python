import json
import requests

access_token = 'EAACEdEose0cBACnF75zJNzQYAOjhrGimEdbT19dRliwZCu1sv7PmmnSZBV3k7ZAiCEMWBYgJj4YHrVo6dipAJJ76DhBSET6szXskPBJbNTix9qSo5JN2XQ3poAae1dA5PgbdAX1WVU00RQi9YaA6U4ZAzpWZCwZB08MVKvZCuyfiwZDZD'

if access_token == None:
    access_token = raw_input("\nCopy and paste token from https://developers.facebook.com/tools/explorer\n>  ") 
# Make sure to use version 2.3 (dropdown on the left of the token at the top of the screen) and check the box for user_groups permission

fb_class_id = '18793419640'

baseurl = "https://graph.facebook.com/v2.3/{}/feed"  

# Building the Facebook parameters dictionary
url_params = {}
url_params["access_token"] = access_token
url_params["fields"] = "message,created_time"
url_params["limit"]=250

# Try and get a response, see what it looks like
r = requests.get(baseurl.format(fb_class_id),params=url_params)
feed = json.loads(r.text)

try:
    f = open("cnn.txt", 'r')
    cnn_dic= json.loads(f.read())
    f.close()
except:
    f = open("cnn.txt", 'w')
    f.write(json.dumps(feed))
    f.close()
    cnn_dic=feed


def readfile(filename):
	f=open(filename,'r')
	lines=f.readlines()
	outputlist=[]
	for i in lines:
		outputlist.append(i.strip())
	return outputlist

country_name=readfile('country.txt')

word_countdic={}
for each_massage in cnn_dic['data']:
	if 'message' in each_massage:
		message_list=each_massage['message'].split()
		#print message_list
		for i in message_list:
			if i in country_name:
				if i not in word_countdic:
					word_countdic[i]=0
				word_countdic[i]+=1

country_common=sorted(word_countdic,key=lambda x: word_countdic[x],reverse=True)

for i in country_common:
	print i,word_countdic[i]

outfile = open("cnn_word.csv","w")
outfile.write("word, counts\n")
for i in country_common:
    outfile.write("{},{}\n".format(i.encode('utf-8'),word_countdic[i]))
outfile.close()
