def flat(tree):
    res = []
    for i in tree:
        if type(i)==type([]):
            res.extend(flat(i))
        else:
            res.append(i)
    return res	
	
my_lst = [[1, 2, 3], "a", [4], [[[5, 6], 7, [8,9]], 10]] 
print flat(my_lst)

r=[1,2]
r.extend([3,3])
print r