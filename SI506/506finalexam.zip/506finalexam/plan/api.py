import json
import requests
import wikipedia
import unittest
import webbrowser



       
base_url = "https://api.flickr.com/services/rest/"
params_d = {}
params_d['method'] = 'flickr.photos.search'
params_d['api_key'] = "e000708b861dce5e414251b565994ada"
params_d['format'] = 'json'
params_d['tags'] = ['China,symbol']
params_d['tag_mode'] = 'all'
params_d['per_page'] = 1
r = requests.get(base_url, params=params_d)

f = open("flickr.txt", 'w')
f.write(json.dumps(r.text[14:-1]))
f.close()


c=wikipedia.summary('China',sentences=8)
f = open("wiki.txt", 'w')
f.write(json.dumps(c))
f.close()
		
access_token = None
if access_token == None:
	access_token = raw_input("\nCopy and paste token from https://developers.facebook.com/tools/explorer\n>  ") 

baseurl = "https://graph.facebook.com/v2.3/{}/feed"  
url_params = {}
url_params["access_token"] = access_token
url_params["fields"] = "message,created_time"
url_params["limit"]=10
r = requests.get(baseurl.format('18793419640'),params=url_params)
feed = json.loads(r.text)
f = open("cnn.txt", 'w')
f.write(json.dumps(feed))
f.close()








