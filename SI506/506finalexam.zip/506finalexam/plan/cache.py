import requests
import json

CACHE_FNAME = 'cache.txt'

try:
    cache_file = open(CACHE_FNAME, 'r')
    cache_contents = cache_file.read()
    CACHE_DICTION = json.loads(cache_contents)
    # CACHE_DICTION = cache_contents
    cache_file.close()
except:
    CACHE_DICTION = {}

def getWithCaching(artist):
    BASE_URL = 'https://itunes.apple.com/search'
    full_url = requestURL(BASE_URL, params={'term': artist, 'media': 'movie'})

    if full_url in CACHE_DICTION:
        print 'using cache'
        # use stored response
        response_text = CACHE_DICTION[full_url]
    else:
        print 'fetching'
        # do the work of calling the API
        response = requests.get(full_url)
        # store the response
        CACHE_DICTION[full_url] = response.text
        response_text = response.text

        cache_file = open(CACHE_FNAME, 'w')
        cache_file.write(json.dumps(CACHE_DICTION))
        cache_file.close()

    response_dictionary = json.loads(response_text)
    return response_dictionary



def canonical_order(d):
    alphabetized_keys = sorted(d.keys())
    res = []
    for k in alphabetized_keys:
        res.append((k, d[k]))
    return res

def requestURL(baseurl, params = {}):
    req = requests.Request(method = 'GET', url = baseurl, params = canonical_order(params))
    prepped = req.prepare()
    return prepped.url

for _ in range(5):
    getWithCaching('Kevin Bacon')